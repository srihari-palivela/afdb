
# AFDB Engine MVP

## Run demo
```bash
cargo run --example demo
```

## Run tests
```bash
cargo test -q
```
